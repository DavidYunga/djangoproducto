from django.contrib import admin
from .models import Producto
 

class AdminProducto(admin.ModelAdmin):
	list_display = ["codigo","nombre","descripcion","cantidad","tipo","precio"]
	#list_filter = ["cedula","apellidoPaterno","apellidoMaterno","nombres","correo","celular"]
	#search_fiels = ["cedula","apellidoPaterno","apellidoMaterno","nombres","celular"]

	class Meta:
		model = Producto

admin.site.register(Producto, AdminProducto)