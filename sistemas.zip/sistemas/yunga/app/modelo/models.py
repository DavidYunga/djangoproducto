from django.db import models

class Producto(models.Model):
	listaProducto = (
		('f', 'Frutas'),
		('e', 'Enlatados'),
		('g','Granos')
	)
	

	codigo = models.CharField('Codigo', max_length = 10, unique = True)
	nombre = models.CharField('Nombre', max_length = 25, blank=False, null = False)
	descripcion = models.CharField('Descripcion', max_length = 50, blank = False, null = False)
	cantidad = models.CharField('Cantidad', max_length = 25, blank = False, null = False)
	tipo = models.CharField(max_length = 10, choices = listaProducto, default ='e')
	precio= models.CharField('Precio', max_length = 25, blank=False, null = False)


	def __str__(self):
		return self.codigo